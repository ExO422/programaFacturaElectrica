﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace appConsumoElectrico
{
    internal class factura
    {
        //Atributos
        private string nombreCliente;
        private int consumo;
        private double tarifa;
        private double cargoFijo;
        private double subsidio;
        
        //M. Constructor
        public factura() { }

        //M. Set
        public void setnombreCliente(string nombreCliente) {this.nombreCliente = nombreCliente;}
        public void setconsumo(int consumo) { this.consumo = consumo;}
        public void settarifa(double tarifa) { this.tarifa = tarifa;}
        public void setcargoFijo(double cargoFijo) { this.cargoFijo = cargoFijo; }
        public void setsubsidio(double subsidio) { this.subsidio = subsidio; }

        //M. Get
        public string getnombreCliente() { return nombreCliente; }
        public int getConsumo() { return consumo; }
        public double gettarifa() { return tarifa; }
        public double getcargoFijo() { return cargoFijo; }
        public double getSubsidio() { return subsidio; }




    }
}
