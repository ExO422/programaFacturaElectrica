﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace appConsumoElectrico
{
    public partial class Form1 : Form
    {
        factura factura1 = new factura();
        public Form1()
        {
            InitializeComponent();

            textBox1.Text = "Cliente";
            textBox2.Text = "0";
            textBox3.Text = "0";
            textBox4.Text = "0";
            textBox5.Text = "0";

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            factura1.setnombreCliente(textBox1.Text);
            factura1.setconsumo(Convert.ToInt32(textBox2.Text));
            factura1.settarifa(Convert.ToDouble(textBox3.Text));
            factura1.setcargoFijo(Convert.ToDouble(textBox4.Text));
            factura1.setsubsidio(Convert.ToDouble(textBox5.Text));

            label13.Text = Convert.ToString(factura1.getConsumo()*factura1.gettarifa());
            label14.Text = Convert.ToString(factura1.getConsumo());
            label15.Text = Convert.ToString((factura1.getConsumo() * factura1.gettarifa())+factura1.getcargoFijo()-factura1.getSubsidio());
            label12.Text = Convert.ToString(factura1.getcargoFijo());

        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";

            label12.Text = "00.00";
            label13.Text = "00.00";
            label14.Text = "00.00";
            label15.Text = "00.00";
        }
    }
}
